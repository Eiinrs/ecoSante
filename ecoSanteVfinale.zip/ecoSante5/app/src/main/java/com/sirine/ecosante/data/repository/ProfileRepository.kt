package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.ProfileDao
import com.sirine.ecosante.data.local.entity.ProfileEntity

class ProfileRepository(private val dao: ProfileDao) {
    suspend fun get(userId: Long): ProfileEntity? = dao.get(userId)
    suspend fun upsert(profile: ProfileEntity) = dao.upsert(profile)
}
