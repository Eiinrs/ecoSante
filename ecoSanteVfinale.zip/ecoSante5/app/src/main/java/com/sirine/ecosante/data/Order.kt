package com.sirine.ecosante.data

data class Order(
    val id: Int,
    val items: List<CartItem>,
    val total: Double,
    val date: String,
    var address: String? = null
)
