package com.sirine.ecosante.data

data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val condition: String,
    val price: Double,
    val imageResId: Int
)
