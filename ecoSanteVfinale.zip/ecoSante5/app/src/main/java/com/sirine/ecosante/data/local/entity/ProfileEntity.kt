package com.sirine.ecosante.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val userId: Long,
    val fullName: String = "",
    val profession: String = "",
    val age: Int = 0,
    val phone: String = "",
    val address: String = ""
)
