package com.sirine.ecosante.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.sirine.ecosante.data.local.entity.ReviewEntity

@Dao
interface ReviewDao {
    @Insert
    suspend fun insert(review: ReviewEntity)

    @Query("SELECT AVG(rating) FROM reviews")
    suspend fun getGlobalRating(): Double?

    @Query("SELECT COUNT(*) FROM reviews")
    suspend fun getCount(): Int

    @Query("SELECT * FROM reviews ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLast(): ReviewEntity?
}
