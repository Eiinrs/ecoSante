package com.sirine.ecosante.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.MainActivity
import com.sirine.ecosante.R
import kotlinx.coroutines.launch

class AuthFragment : Fragment() {

    private lateinit var viewModel: AuthViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_auth, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1) Brancher le ViewModel (Room + Session)
        val app = requireActivity().application as EcoSanteApp
        viewModel = ViewModelProvider(
            this,
            AuthViewModelFactory(
                app.container.authRepository,
                app.container.sessionManager
            )
        )[AuthViewModel::class.java]

        val editEmail = view.findViewById<EditText>(R.id.editTextEmail)
        val editPassword = view.findViewById<EditText>(R.id.editTextPassword)
        val buttonLogin = view.findViewById<Button>(R.id.buttonLogin)
        val buttonRegister = view.findViewById<Button>(R.id.buttonRegister)
        val textSkip = view.findViewById<TextView>(R.id.textSkip)

        // 2) Observer l'état (erreurs / loading)
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.ui.collect { state ->
                state.error?.let { msg ->
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearError()
                }
                // Si tu as une progressBar dans le layout, tu peux la gérer ici
                // binding.progressBar.visibility = if (state.loading) View.VISIBLE else View.GONE
            }
        }

        // 3) Connexion réelle (Room + SessionManager)
        buttonLogin.setOnClickListener {
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()

            viewModel.login(email, password) {
                startActivity(Intent(requireContext(), MainActivity::class.java))
                requireActivity().finish()
            }
        }

        // 4) Aller vers l'inscription (tu peux garder ton RegisterFragment)
        buttonRegister.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.authFragmentContainer, RegisterFragment())
                .addToBackStack(null)
                .commit()
        }

        // 5) Skip (démo)
        textSkip.setOnClickListener {
            startActivity(Intent(requireContext(), MainActivity::class.java))
            requireActivity().finish()
        }
    }
}
