package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.OrderDao
import com.sirine.ecosante.data.local.entity.OrderEntity
import com.sirine.ecosante.data.local.entity.OrderItemEntity
import com.sirine.ecosante.data.local.model.OrderWithItems

class OrderRepository(private val dao: OrderDao) {

    suspend fun placeOrder(
        userId: Long,
        address: String,
        items: List<OrderItemEntity>,
        total: Double
    ): Long {
        val orderId = dao.insertOrder(
            OrderEntity(
                userId = userId,
                total = total,
                address = address
            )
        )

        val linked = items.map { it.copy(orderId = orderId, userId = userId) }
        dao.insertItems(linked)

        return orderId
    }

    suspend fun getOrders(userId: Long): List<OrderWithItems> = dao.getOrdersWithItems(userId)
    suspend fun count(userId: Long): Int = dao.count(userId)
    suspend fun getLast(userId: Long): OrderEntity? = dao.getLast(userId)
}
