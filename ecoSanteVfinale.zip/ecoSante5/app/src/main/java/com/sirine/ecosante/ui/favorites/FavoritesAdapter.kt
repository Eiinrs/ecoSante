package com.sirine.ecosante.ui.favorites

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.R
import com.sirine.ecosante.data.Product

class FavoritesAdapter(
    private val products: List<Product>
) : RecyclerView.Adapter<FavoritesAdapter.FavViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_product, parent, false)
        return FavViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavViewHolder, position: Int) {
        holder.bind(products[position])
    }

    override fun getItemCount(): Int = products.size

    class FavViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val image = itemView.findViewById<ImageView>(R.id.imageProduct)
        private val name = itemView.findViewById<TextView>(R.id.textName)
        private val price = itemView.findViewById<TextView>(R.id.textPrice)

        fun bind(product: Product) {
            name.text = product.name
            price.text = "${product.price} €"
            image.setImageResource(product.imageResId)
        }
    }
}
