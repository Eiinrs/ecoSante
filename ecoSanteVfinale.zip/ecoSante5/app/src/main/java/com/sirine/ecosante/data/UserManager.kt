package com.sirine.ecosante.data

object UserManager {

    var currentUser: User? = null
    private val users = mutableListOf<User>()

    fun register(user: User) {
        users.add(user)
        currentUser = user
    }

    fun login(email: String, password: String): Boolean {
        val user = users.find { it.email == email && it.password == password }
        currentUser = user
        return user != null
    }
}
