package com.sirine.ecosante.ui.cart

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.R
import com.sirine.ecosante.data.CartItem
import com.sirine.ecosante.data.CartManager

class CartAdapter(
    private var items: MutableList<CartItem>,
    private val onCartChanged: () -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val checkItem: CheckBox = itemView.findViewById(R.id.checkItem)
        val imageProduct: ImageView = itemView.findViewById(R.id.imageProduct)
        val textName: TextView = itemView.findViewById(R.id.textName)
        val textUnitPrice: TextView = itemView.findViewById(R.id.textUnitPrice)
        val textSubtotal: TextView = itemView.findViewById(R.id.textSubtotal)
        val buttonMinus: Button = itemView.findViewById(R.id.buttonMinus)
        val buttonPlus: Button = itemView.findViewById(R.id.buttonPlus)
        val textQuantity: TextView = itemView.findViewById(R.id.textQuantity)
        val buttonDelete: ImageButton = itemView.findViewById(R.id.buttonDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = items[position]
        val product = item.product

        holder.imageProduct.setImageResource(product.imageResId)
        holder.textName.text = product.name
        holder.textUnitPrice.text = "Prix unitaire : ${product.price} €"
        holder.textQuantity.text = item.quantity.toString()
        holder.textSubtotal.text = "Sous-total : ${product.price * item.quantity} €"

        holder.checkItem.setOnCheckedChangeListener(null)
        holder.checkItem.isChecked = item.isSelected

        holder.checkItem.setOnCheckedChangeListener { _, isChecked ->
            item.isSelected = isChecked
            CartManager.setItemSelected(product, isChecked)
            onCartChanged()
        }

        holder.buttonPlus.setOnClickListener {
            val newQty = item.quantity + 1
            item.quantity = newQty
            CartManager.updateQuantity(product, newQty)
            notifyItemChanged(adapterPositionSafe(holder))
            onCartChanged()
        }

        holder.buttonMinus.setOnClickListener {
            val newQty = item.quantity - 1
            if (newQty <= 0) {
                CartManager.removeFromCart(product)
                val pos = adapterPositionSafe(holder)
                items.removeAt(pos)
                notifyItemRemoved(pos)
            } else {
                item.quantity = newQty
                CartManager.updateQuantity(product, newQty)
                notifyItemChanged(adapterPositionSafe(holder))
            }
            onCartChanged()
        }

        holder.buttonDelete.setOnClickListener {
            CartManager.removeFromCart(product)
            val pos = adapterPositionSafe(holder)
            items.removeAt(pos)
            notifyItemRemoved(pos)
            onCartChanged()
        }
    }

    private fun adapterPositionSafe(holder: RecyclerView.ViewHolder): Int {
        val pos = holder.bindingAdapterPosition
        return if (pos == RecyclerView.NO_POSITION) 0 else pos
    }

    fun updateItems(newItems: List<CartItem>) {
        items = newItems.toMutableList()
        notifyDataSetChanged()
    }
}
