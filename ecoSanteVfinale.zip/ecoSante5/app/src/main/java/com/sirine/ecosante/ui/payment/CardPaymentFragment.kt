package com.sirine.ecosante.ui.payment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.data.CartManager
import com.sirine.ecosante.data.FakeRepository
import com.sirine.ecosante.data.local.entity.OrderItemEntity
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.Calendar

class CardPaymentFragment : Fragment() {

    private lateinit var textTotalToPay: TextView
    private lateinit var editCardHolder: EditText
    private lateinit var editCardNumber: EditText
    private lateinit var editExpiry: EditText
    private lateinit var editCvv: EditText
    private lateinit var editAddress: EditText
    private lateinit var buttonPayNow: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_card_payment, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        textTotalToPay = view.findViewById(R.id.textTotalToPay)
        editCardHolder = view.findViewById(R.id.editCardHolder)
        editCardNumber = view.findViewById(R.id.editCardNumber)
        editExpiry = view.findViewById(R.id.editExpiry)
        editCvv = view.findViewById(R.id.editCvv)
        editAddress = view.findViewById(R.id.editAddress)
        buttonPayNow = view.findViewById(R.id.buttonPayNow)

        val selectedItems = CartManager.getItems().filter { it.isSelected }
        val total = selectedItems.sumOf { it.product.price * it.quantity }
        textTotalToPay.text = "Montant : ${"%.2f".format(total)} €"

        // format MM/AA
        editExpiry.addTextChangedListener(object : TextWatcher {
            private var editing = false
            override fun afterTextChanged(s: Editable?) {
                if (editing) return
                editing = true

                val raw = s.toString().replace("/", "").take(4)
                val formatted = if (raw.length <= 2) raw else raw.substring(0, 2) + "/" + raw.substring(2)

                editExpiry.setText(formatted)
                editExpiry.setSelection(formatted.length)
                editing = false
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        buttonPayNow.setOnClickListener {
            val holder = editCardHolder.text.toString().trim()
            val card = editCardNumber.text.toString().trim()
            val exp = editExpiry.text.toString().trim()
            val cvv = editCvv.text.toString().trim()
            val address = editAddress.text.toString().trim()

            if (holder.isEmpty() || holder.length > 30) return@setOnClickListener toast("Titulaire invalide")
            if (card.length != 16) return@setOnClickListener toast("Carte invalide")
            if (!isExpiryValid(exp)) return@setOnClickListener toast("Expiration invalide")
            if (cvv.length != 3) return@setOnClickListener toast("CVV invalide")
            if (address.isEmpty()) return@setOnClickListener toast("Adresse requise")

            val app = requireActivity().application as EcoSanteApp
            val session = app.container.sessionManager
            val orderRepo = app.container.orderRepository

            viewLifecycleOwner.lifecycleScope.launch {
                val userId = session.currentUserId.firstOrNull()
                    ?: return@launch toast("Connecte-toi")

                val items = selectedItems.map {
                    OrderItemEntity(
                        userId = userId,
                        productId = it.product.id.toLong(),
                        name = it.product.name,
                        quantity = it.quantity,
                        unitPrice = it.product.price
                    )
                }

                orderRepo.placeOrder(
                    userId = userId,
                    address = address,
                    items = items,
                    total = total
                )

                //  VIDAGE DU PANIER (CORRIGÉ)
                CartManager.clearSelected()

                toast("Commande enregistrée !")
                parentFragmentManager.popBackStack()
            }
        }
    }

    private fun isExpiryValid(value: String): Boolean {
        if (!Regex("""\d{2}/\d{2}""").matches(value)) return false
        val mm = value.substring(0, 2).toInt()
        val yy = value.substring(3, 5).toInt()
        if (mm !in 1..12) return false

        val cal = Calendar.getInstance()
        val curYY = cal.get(Calendar.YEAR) % 100
        val curMM = cal.get(Calendar.MONTH) + 1

        return yy > curYY || (yy == curYY && mm >= curMM)
    }

    private fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }
}
