package com.sirine.ecosante.data

object CartManager {

    private val items = mutableListOf<CartItem>()

    fun getItems(): List<CartItem> = items

    fun addToCart(product: Product, quantity: Int) {
        val existing = items.find { it.product.id == product.id }
        if (existing != null) {
            existing.quantity += quantity
        } else {
            items.add(
                CartItem(
                    product = product,
                    quantity = quantity,
                    isSelected = true
                )
            )
        }
    }

    fun removeFromCart(product: Product) {
        items.removeAll { it.product.id == product.id }
    }

    fun updateQuantity(product: Product, quantity: Int) {
        items.find { it.product.id == product.id }?.quantity = quantity
    }

    fun setItemSelected(product: Product, selected: Boolean) {
        items.find { it.product.id == product.id }?.isSelected = selected
    }

    fun setAllSelected(selected: Boolean) {
        items.forEach { it.isSelected = selected }
    }

    fun getTotalPrice(onlySelected: Boolean = false): Double {
        return items
            .filter { !onlySelected || it.isSelected }
            .sumOf { it.product.price * it.quantity }
    }

    /**
     *  MÉTHODE OFFICIELLE
     * Supprime tous les articles sélectionnés
     */
    fun clearSelected() {
        items.removeAll { it.isSelected }
    }

    fun clearAll() {
        items.clear()
    }
}
