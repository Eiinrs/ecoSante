package com.sirine.ecosante.ui.orders

import com.sirine.ecosante.data.local.model.OrderWithItems
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OrdersExportHelper {

    fun toTxt(orders: List<OrderWithItems>): String {
        val sb = StringBuilder()
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

        sb.append("Historique des commandes - écoSanté\n")
        sb.append("=================================\n\n")

        if (orders.isEmpty()) {
            sb.append("Aucune commande enregistrée.\n")
            return sb.toString()
        }

        orders.forEach { ow ->
            sb.append("Commande #${ow.order.id}\n")

            //  date correcte depuis createdAt
            val dateFormatted = sdf.format(Date(ow.order.createdAt))
            sb.append("Date : $dateFormatted\n")

            if (ow.order.address.isNotBlank()) {
                sb.append("Adresse : ${ow.order.address}\n")
            }

            sb.append("Total : ${"%.2f".format(ow.order.total)} €\n")
            sb.append("Articles :\n")

            ow.items.forEach { item ->
                sb.append(
                    " - ${item.name} x${item.quantity} (${item.unitPrice} €)\n"
                )
            }

            sb.append("\n---------------------------------\n\n")
        }

        return sb.toString()
    }
}
