package com.sirine.ecosante

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.sirine.ecosante.data.local.db.EcoSanteDatabase
import com.sirine.ecosante.data.repository.*
import com.sirine.ecosante.data.session.SessionManager

// ✅ Migration 2 -> 3 : Orders + OrderItems
private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `orders` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `userId` INTEGER NOT NULL,
                `total` REAL NOT NULL,
                `address` TEXT NOT NULL,
                `createdAt` INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `order_items` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `orderId` INTEGER NOT NULL,
                `userId` INTEGER NOT NULL,
                `productId` INTEGER NOT NULL,
                `name` TEXT NOT NULL,
                `quantity` INTEGER NOT NULL,
                `unitPrice` REAL NOT NULL
            )
            """.trimIndent()
        )

        // Index (optionnel)
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_userId` ON `orders` (`userId`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_orderId` ON `order_items` (`orderId`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_userId` ON `order_items` (`userId`)")
    }
}

class AppContainer(context: Context) {

    private val db: EcoSanteDatabase =
        Room.databaseBuilder(context.applicationContext, EcoSanteDatabase::class.java, "ecosante.db")
            .addMigrations(MIGRATION_2_3)
            // ✅ pendant le dev : évite crash si tu changes de version à l’envers
            .fallbackToDestructiveMigrationOnDowngrade()
            .build()

    // DAOs
    private val userDao = db.userDao()
    private val profileDao = db.profileDao()
    private val favoriteDao = db.favoriteDao()
    private val reviewDao = db.reviewDao()
    private val orderDao = db.orderDao()
    private val savDao = db.savDao()

    // Session
    val sessionManager = SessionManager(context.applicationContext)

    // Repositories
    val authRepository = AuthRepository(userDao, profileDao)
    val profileRepository = ProfileRepository(profileDao)
    val favoriteRepository = FavoriteRepository(favoriteDao)
    val reviewRepository = ReviewRepository(reviewDao)
    val orderRepository = OrderRepository(orderDao)
    val savRepository = SavRepository(savDao)
}
