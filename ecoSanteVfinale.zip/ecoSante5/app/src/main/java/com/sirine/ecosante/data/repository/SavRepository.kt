package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.SavDao
import com.sirine.ecosante.data.local.entity.SavMessageEntity

class SavRepository(private val dao: SavDao) {
    suspend fun send(userId: Long, message: String) =
        dao.insert(SavMessageEntity(userId = userId, message = message))

    suspend fun count(userId: Long) = dao.count(userId)
    suspend fun getLast(userId: Long) = dao.getLast(userId)
    suspend fun getAll(userId: Long) = dao.getAll(userId)
}
