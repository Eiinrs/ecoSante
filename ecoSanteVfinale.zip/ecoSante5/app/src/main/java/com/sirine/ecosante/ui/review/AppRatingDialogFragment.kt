package com.sirine.ecosante.ui.contact

import android.app.Dialog
import android.os.Bundle
import android.widget.RatingBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import kotlinx.coroutines.launch

class AppRatingDialogFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = requireActivity().layoutInflater
            .inflate(R.layout.dialog_app_rating, null)

        val ratingBar = view.findViewById<RatingBar>(R.id.ratingBar)
        val textAverage = view.findViewById<TextView>(R.id.textAverage)
        val textCount = view.findViewById<TextView>(R.id.textCount)
        val textLast = view.findViewById<TextView>(R.id.textLast)

        val app = requireActivity().application as EcoSanteApp
        val reviewRepo = app.container.reviewRepository

        lifecycleScope.launch {
            val summary = reviewRepo.getSummary()

            // Affiche aussi la note dans le RatingBar
            ratingBar.rating = summary.average?.toFloat() ?: 0f

            textAverage.text = "Note moyenne : ${summary.average ?: "-"} ⭐"
            textCount.text = "${summary.count} avis"

            textLast.text = summary.last?.let {
                "Dernier avis : ${it.rating} ⭐\n${it.comment}"
            } ?: "Aucun avis pour le moment"
        }

        return AlertDialog.Builder(requireContext())
            .setTitle("Note de l'application")
            .setView(view)
            .setPositiveButton("OK", null)
            .create()
    }
}
