package com.sirine.ecosante.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sirine.ecosante.data.local.entity.ProfileEntity

@Dao
interface ProfileDao {

    @Query("SELECT * FROM profiles WHERE userId = :userId LIMIT 1")
    suspend fun get(userId: Long): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: ProfileEntity)
}
