package com.sirine.ecosante.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sirine.ecosante.data.local.dao.*
import com.sirine.ecosante.data.local.entity.*

@Database(
    entities = [
        UserEntity::class,
        ProfileEntity::class,
        FavoriteEntity::class,
        ReviewEntity::class,
        SavMessageEntity::class,
        OrderEntity::class,
        OrderItemEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class EcoSanteDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun profileDao(): ProfileDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun reviewDao(): ReviewDao
    abstract fun savDao(): SavDao

    // AJOUT OBLIGATOIRE pour AppContainer
    abstract fun orderDao(): OrderDao
}
