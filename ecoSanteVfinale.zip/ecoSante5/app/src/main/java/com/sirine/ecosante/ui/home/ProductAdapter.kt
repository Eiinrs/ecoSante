package com.sirine.ecosante.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.data.Product
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class ProductAdapter(
    private var items: List<Product>,
    private val onDetailsClick: (Product) -> Unit,
    private val scope: CoroutineScope
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageProduct: ImageView = itemView.findViewById(R.id.imageProduct)
        val textName: TextView = itemView.findViewById(R.id.textName)
        val textCategory: TextView = itemView.findViewById(R.id.textCategory)
        val textPrice: TextView = itemView.findViewById(R.id.textPrice)
        val buttonDetails: Button = itemView.findViewById(R.id.buttonAddToCart)
        val buttonFavorite: ImageButton = itemView.findViewById(R.id.buttonFavorite)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = items[position]

        // UI produit
        holder.imageProduct.setImageResource(product.imageResId)
        holder.textName.text = product.name
        holder.textCategory.text = product.category
        holder.textPrice.text = "${product.price} €"

        // Détails
        holder.buttonDetails.text = "+ DÉTAILS"
        holder.buttonDetails.setOnClickListener { onDetailsClick(product) }

        // Favoris Room + Session
        val app = holder.itemView.context.applicationContext as EcoSanteApp
        val favRepo = app.container.favoriteRepository
        val session = app.container.sessionManager

        val productIdLong = product.id.toLong()

        fun setFavIcon(isFav: Boolean) {
            holder.buttonFavorite.setImageResource(
                if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )
        }

        // Etat initial (important car RecyclerView recycle)
        scope.launch {
            val userId = session.currentUserId.firstOrNull()
            if (userId == null) {
                setFavIcon(false)
            } else {
                val isFav = favRepo.isFavorite(userId, productIdLong)
                setFavIcon(isFav)
            }
        }

        // Toggle favoris
        holder.buttonFavorite.setOnClickListener {
            scope.launch {
                val userId = session.currentUserId.firstOrNull()
                if (userId == null) {
                    Toast.makeText(
                        holder.itemView.context,
                        "Connecte-toi pour ajouter aux favoris",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@launch
                }

                val newState = favRepo.toggle(userId, productIdLong)
                setFavIcon(newState)
            }
        }
    }

    fun updateData(newItems: List<Product>) {
        items = newItems
        notifyDataSetChanged()
    }
}
