package com.sirine.ecosante.data.local.dao

data class ReviewMini(
    val rating: Int,
    val comment: String
)
