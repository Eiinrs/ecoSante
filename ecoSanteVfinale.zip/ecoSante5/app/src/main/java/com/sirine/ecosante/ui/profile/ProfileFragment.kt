package com.sirine.ecosante.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.AuthActivity
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.ui.contact.AppRatingDialogFragment
import com.sirine.ecosante.ui.orders.OrdersExportHelper
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProfileFragment : Fragment() {

    private lateinit var textName: TextView
    private lateinit var textEmail: TextView
    private lateinit var textProfession: TextView
    private lateinit var textAge: TextView
    private lateinit var buttonLogout: ImageButton

    private lateinit var textGlobalRating: TextView
    private lateinit var textOrders: TextView
    private lateinit var textFavorites: TextView
    private lateinit var textSav: TextView

    private var buttonExportInfos: Button? = null

    private val createTxtLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            if (uri == null) return@registerForActivityResult

            viewLifecycleOwner.lifecycleScope.launch {
                val app = requireActivity().application as EcoSanteApp
                val userId = app.container.sessionManager.currentUserId.firstOrNull()

                if (userId == null) {
                    Toast.makeText(requireContext(), "Connecte-toi pour exporter.", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val orders = app.container.orderRepository.getOrders(userId)
                val sav = app.container.savRepository.getAll(userId)

                val txt = buildInfosExportTxt(userId, orders, sav)

                requireContext().contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(txt.toByteArray(Charsets.UTF_8))
                }

                Toast.makeText(requireContext(), "Export terminé ", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_profile, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        textName = view.findViewById(R.id.textName)
        textEmail = view.findViewById(R.id.textEmail)
        textProfession = view.findViewById(R.id.textProfession)
        textAge = view.findViewById(R.id.textAge)
        buttonLogout = view.findViewById(R.id.buttonLogout)

        textGlobalRating = view.findViewById(R.id.textGlobalRating)
        textOrders = view.findViewById(R.id.textOrders)
        textFavorites = view.findViewById(R.id.textFavorites)
        textSav = view.findViewById(R.id.textSav)

        //  le bon id du bouton
        buttonExportInfos = view.findViewById(R.id.buttonExportInfosTxt)

        val app = requireActivity().application as EcoSanteApp
        val session = app.container.sessionManager

        textName.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, EditProfileFragment())
                .addToBackStack(null)
                .commit()
        }

        textGlobalRating.setOnClickListener {
            AppRatingDialogFragment().show(parentFragmentManager, "app_rating")
        }

        //  clique => ouvre "Enregistrer sous"
        buttonExportInfos?.setOnClickListener {
            val filename = "ecosante_infos_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.txt"
            createTxtLauncher.launch(filename)
        }

        buttonLogout.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                session.logout()
                Toast.makeText(requireContext(), "Déconnecté(e)", Toast.LENGTH_SHORT).show()
                val intent = Intent(requireContext(), AuthActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            val userId = session.currentUserId.firstOrNull()
            if (userId == null) {
                showGuest()
            } else {
                loadHeader(userId)
                refreshCards(userId)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = requireActivity().application as EcoSanteApp
        val session = app.container.sessionManager

        viewLifecycleOwner.lifecycleScope.launch {
            val userId = session.currentUserId.firstOrNull()
            if (userId == null) showGuest()
            else {
                loadHeader(userId)
                refreshCards(userId)
            }
        }
    }

    private fun showGuest() {
        textName.text = "Utilisateur invité"
        textEmail.text = "Non connecté"
        textProfession.text = "-"
        textAge.text = "-"

        textGlobalRating.text = "Connectez-vous pour voir la note."
        textOrders.text = "Connectez-vous pour voir vos commandes."
        textFavorites.text = "Connectez-vous pour voir vos favoris."
        textSav.text = "Connectez-vous pour voir vos messages SAV."

        buttonExportInfos?.isEnabled = false
    }

    private suspend fun loadHeader(userId: Long) {
        val app = requireActivity().application as EcoSanteApp
        val profile = app.container.profileRepository.get(userId)

        textName.text = profile?.fullName?.takeIf { it.isNotBlank() } ?: "Mon profil"
        textProfession.text = profile?.profession?.takeIf { it.isNotBlank() } ?: "-"
        val age = profile?.age ?: 0
        textAge.text = if (age > 0) "$age ans" else "-"
        textEmail.text = "Compte #$userId"

        buttonExportInfos?.isEnabled = true
    }

    private suspend fun refreshCards(userId: Long) {
        val app = requireActivity().application as EcoSanteApp

        val summary = app.container.reviewRepository.getSummary()
        textGlobalRating.text =
            if (summary.count == 0) "Aucune note pour le moment."
            else "Note moyenne : ${"%.1f".format(summary.average ?: 0.0)} / 5  •  ${summary.count} avis"

        val favCount = app.container.favoriteRepository.getIds(userId).size
        textFavorites.text =
            if (favCount == 0) "Vous n'avez pas encore de favoris."
            else "Vous avez $favCount favoris."

        val orderRepo = app.container.orderRepository
        val count = orderRepo.count(userId)
        val last = orderRepo.getLast(userId)
        textOrders.text =
            if (count == 0) "Aucune commande pour le moment."
            else "Vous avez $count commande(s). Dernière : ${"%.2f".format(last?.total ?: 0.0)} €"

        val savRepo = app.container.savRepository
        val savCount = savRepo.count(userId)
        val lastSav = savRepo.getLast(userId)
        textSav.text =
            if (savCount == 0) "Aucun message SAV."
            else {
                val preview = (lastSav?.message ?: "").take(40).let { if (it.length == 40) "$it…" else it }
                "$savCount message(s) SAV. Dernier: $preview"
            }
    }

    private fun buildInfosExportTxt(
        userId: Long,
        orders: List<com.sirine.ecosante.data.local.model.OrderWithItems>,
        sav: List<com.sirine.ecosante.data.local.entity.SavMessageEntity>
    ): String {
        val sb = StringBuilder()
        val now = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        sb.append("Export écoSanté - $now\n")
        sb.append("UserId: $userId\n\n")

        sb.append("=== HISTORIQUE DES COMMANDES ===\n\n")
        sb.append(OrdersExportHelper.toTxt(orders))
        sb.append("\n\n")

        sb.append("=== MESSAGES SAV ===\n\n")
        if (sav.isEmpty()) {
            sb.append("Aucun message SAV.\n")
        } else {
            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            sav.forEach { msg ->
                sb.append("- ${sdf.format(Date(msg.createdAt))} : ${msg.message}\n")
            }
        }

        return sb.toString()
    }
}
