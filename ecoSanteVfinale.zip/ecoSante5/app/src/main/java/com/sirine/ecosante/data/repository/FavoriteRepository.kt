package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.FavoriteDao
import com.sirine.ecosante.data.local.entity.FavoriteEntity

class FavoriteRepository(private val dao: FavoriteDao) {

    suspend fun isFavorite(userId: Long, productId: Long): Boolean =
        dao.isFavorite(userId, productId)

    suspend fun add(userId: Long, productId: Long) {
        dao.add(FavoriteEntity(userId = userId, productId = productId))
    }

    suspend fun remove(userId: Long, productId: Long) {
        dao.remove(userId, productId)
    }

    suspend fun toggle(userId: Long, productId: Long): Boolean {
        val fav = dao.isFavorite(userId, productId)
        if (fav) dao.remove(userId, productId) else dao.add(FavoriteEntity(userId, productId))
        return !fav // retourne le nouvel état
    }

    suspend fun getIds(userId: Long): List<Long> = dao.getFavoriteProductIds(userId)

    suspend fun count(userId: Long): Int = dao.getFavoriteProductIds(userId).size
}
