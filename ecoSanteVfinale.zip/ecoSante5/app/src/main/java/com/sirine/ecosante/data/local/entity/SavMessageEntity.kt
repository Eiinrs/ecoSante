package com.sirine.ecosante.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sav_messages")
data class SavMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val message: String,
    val isFromUser: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
