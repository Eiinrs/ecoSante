package com.sirine.ecosante.data

data class User(
    val firstName: String,
    val lastName: String,
    val age: Int,
    val profession: String,
    val email: String,
    val password: String
)
