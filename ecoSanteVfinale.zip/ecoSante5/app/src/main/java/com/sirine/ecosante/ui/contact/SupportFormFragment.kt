package com.sirine.ecosante.ui.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.data.local.db.DbProvider
import com.sirine.ecosante.data.local.entity.SavMessageEntity
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class SupportFormFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_support_form, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val editEmail = view.findViewById<EditText>(R.id.editSupportEmail)
        val editSubject = view.findViewById<EditText>(R.id.editSupportSubject)
        val editMessage = view.findViewById<EditText>(R.id.editSupportMessage)
        val buttonSend = view.findViewById<Button>(R.id.buttonSendSupport)

        buttonSend.setOnClickListener {
            val email = editEmail.text.toString().trim()
            val subject = editSubject.text.toString().trim()
            val message = editMessage.text.toString().trim()

            if (email.isBlank() || subject.isBlank() || message.isBlank()) {
                Toast.makeText(requireContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val app = requireActivity().application as EcoSanteApp
            val session = app.container.sessionManager
            val savDao = DbProvider.get(requireContext()).savDao()

            viewLifecycleOwner.lifecycleScope.launch {
                val userId = session.currentUserId.firstOrNull()
                if (userId == null) {
                    Toast.makeText(requireContext(), "Connecte-toi pour contacter le SAV", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val fullMsg = "[$subject]\n$message"
                savDao.insert(SavMessageEntity(userId = userId, message = fullMsg, isFromUser = true))

                Toast.makeText(requireContext(), "Message SAV enregistré ", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
        }
    }
}
