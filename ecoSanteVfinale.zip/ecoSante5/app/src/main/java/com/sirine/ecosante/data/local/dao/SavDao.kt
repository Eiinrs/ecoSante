package com.sirine.ecosante.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.sirine.ecosante.data.local.entity.SavMessageEntity

@Dao
interface SavDao {

    @Insert
    suspend fun insert(msg: SavMessageEntity)

    @Query("SELECT COUNT(*) FROM sav_messages WHERE userId = :userId")
    suspend fun count(userId: Long): Int

    @Query("SELECT * FROM sav_messages WHERE userId = :userId ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLast(userId: Long): SavMessageEntity?

    @Query("SELECT * FROM sav_messages WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun getAll(userId: Long): List<SavMessageEntity>
}
