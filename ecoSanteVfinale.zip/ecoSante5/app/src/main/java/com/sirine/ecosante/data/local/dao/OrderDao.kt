package com.sirine.ecosante.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import com.sirine.ecosante.data.local.entity.OrderEntity
import com.sirine.ecosante.data.local.entity.OrderItemEntity
import com.sirine.ecosante.data.local.model.OrderWithItems

@Dao
interface OrderDao {

    @Insert
    suspend fun insertOrder(order: OrderEntity): Long

    @Insert
    suspend fun insertItems(items: List<OrderItemEntity>)

    @Transaction
    @Query("SELECT * FROM orders WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun getOrdersWithItems(userId: Long): List<OrderWithItems>

    @Query("SELECT COUNT(*) FROM orders WHERE userId = :userId")
    suspend fun count(userId: Long): Int

    @Query("SELECT * FROM orders WHERE userId = :userId ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLast(userId: Long): OrderEntity?
}
