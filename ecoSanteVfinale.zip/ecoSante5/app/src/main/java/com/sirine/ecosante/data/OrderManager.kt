package com.sirine.ecosante.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OrderManager {

    private val orders = mutableListOf<Order>()
    private var nextId = 1

    fun addOrder(items: List<CartItem>, total: Double): Order {
        val now = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val copyItems = items.map { it.copy() }
        val order = Order(
            id = nextId++,
            items = copyItems,
            total = total,
            date = now
        )
        orders.add(order)
        return order
    }

    fun getOrders(): List<Order> = orders

    fun updateLastOrderAddress(address: String) {
        val last = orders.lastOrNull() ?: return
        last.address = address
    }

    fun clear() {
        orders.clear()
        nextId = 1
    }
}
