package com.sirine.ecosante.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.data.local.entity.ProfileEntity
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class EditProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_edit_profile, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val editFullName = view.findViewById<EditText>(R.id.editFullName)
        val editProfession = view.findViewById<EditText>(R.id.editProfession)
        val editAge = view.findViewById<EditText>(R.id.editAge)
        val editPhone = view.findViewById<EditText>(R.id.editPhone)
        val editAddress = view.findViewById<EditText>(R.id.editAddress)
        val buttonSave = view.findViewById<Button>(R.id.buttonSave)

        val app = requireActivity().application as EcoSanteApp
        val session = app.container.sessionManager
        val profileRepo = app.container.profileRepository

        // Charger le profil
        viewLifecycleOwner.lifecycleScope.launch {
            val userId = session.currentUserId.firstOrNull()
            if (userId == null) {
                Toast.makeText(requireContext(), "Connecte-toi d’abord", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
                return@launch
            }

            val profile = profileRepo.get(userId)
            if (profile != null) {
                editFullName.setText(profile.fullName)
                editProfession.setText(profile.profession)
                editAge.setText(if (profile.age == 0) "" else profile.age.toString())
                editPhone.setText(profile.phone)
                editAddress.setText(profile.address)
            }
        }

        // Sauvegarder
        buttonSave.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                val userId = session.currentUserId.firstOrNull()
                if (userId == null) {
                    Toast.makeText(requireContext(), "Connecte-toi d’abord", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val fullName = editFullName.text.toString().trim()
                val profession = editProfession.text.toString().trim()
                val age = editAge.text.toString().trim().toIntOrNull() ?: 0
                val phone = editPhone.text.toString().trim()
                val address = editAddress.text.toString().trim()

                if (fullName.length < 2) {
                    Toast.makeText(requireContext(), "Nom trop court", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                if (age <= 0) {
                    Toast.makeText(requireContext(), "Âge invalide", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                profileRepo.upsert(
                    ProfileEntity(
                        userId = userId,
                        fullName = fullName,
                        profession = profession,
                        age = age,
                        phone = phone,
                        address = address
                    )
                )

                Toast.makeText(requireContext(), "Profil enregistré !", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
        }
    }
}
