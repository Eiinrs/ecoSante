package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.ProfileDao
import com.sirine.ecosante.data.local.dao.UserDao
import com.sirine.ecosante.data.local.entity.ProfileEntity
import com.sirine.ecosante.data.local.entity.UserEntity

class AuthRepository(
    private val userDao: UserDao,
    private val profileDao: ProfileDao
) {
    suspend fun register(
        email: String,
        password: String,
        fullName: String,
        profession: String,
        age: Int
    ): Long {
        val userId = userDao.insert(
            UserEntity(
                email = email,
                password = password
            )
        )

        profileDao.upsert(
            ProfileEntity(
                userId = userId,
                fullName = fullName,
                profession = profession,
                age = age,
                phone = "",
                address = ""
            )
        )

        return userId
    }

    suspend fun login(email: String, password: String): Long {
        val user = userDao.login(email, password)
            ?: throw IllegalArgumentException("Email ou mot de passe incorrect")
        return user.id // ici c’est id maintenant
    }

    suspend fun emailExists(email: String): Boolean {
        return userDao.countByEmail(email) > 0
    }
}
