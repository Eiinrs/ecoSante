package com.sirine.ecosante.data.repository

import com.sirine.ecosante.data.local.dao.ReviewDao
import com.sirine.ecosante.data.local.entity.ReviewEntity

data class ReviewSummary(
    val average: Double?,
    val count: Int,
    val last: ReviewEntity?
)

class ReviewRepository(private val dao: ReviewDao) {

    // La méthode que FeedbackFragment veut appeler
    suspend fun addReview(userId: Long, rating: Int, comment: String) {
        dao.insert(
            ReviewEntity(
                userId = userId,
                rating = rating,
                comment = comment
            )
        )
    }

    suspend fun getSummary(): ReviewSummary {
        val avg = dao.getGlobalRating()
        val count = dao.getCount()
        val last = dao.getLast()
        return ReviewSummary(avg, count, last)
    }
}
