package com.sirine.ecosante.ui.favorites

import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import com.sirine.ecosante.data.FakeRepository
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class FavoritesFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_favorites, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerFavorites)
        val empty = view.findViewById<TextView>(R.id.textEmptyFavorites)

        recycler.layoutManager = LinearLayoutManager(requireContext())

        val app = requireActivity().application as EcoSanteApp
        val session = app.container.sessionManager
        val favRepo = app.container.favoriteRepository

        viewLifecycleOwner.lifecycleScope.launch {
            val userId = session.currentUserId.firstOrNull()
            if (userId == null) {
                empty.text = "Connectez-vous pour voir vos favoris."
                empty.visibility = View.VISIBLE
                recycler.visibility = View.GONE
                return@launch
            }

            val favIds = favRepo.getIds(userId).toSet()
            val products = FakeRepository.getProducts().filter { favIds.contains(it.id.toLong()) }

            if (products.isEmpty()) {
                empty.text = "Aucun favori."
                empty.visibility = View.VISIBLE
                recycler.visibility = View.GONE
            } else {
                empty.visibility = View.GONE
                recycler.visibility = View.VISIBLE
                recycler.adapter = FavoritesAdapter(products)
            }
        }
    }
}
