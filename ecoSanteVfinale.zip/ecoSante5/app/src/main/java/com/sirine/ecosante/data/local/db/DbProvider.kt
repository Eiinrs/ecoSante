package com.sirine.ecosante.data.local.db

import android.content.Context
import androidx.room.Room

object DbProvider {
    @Volatile private var INSTANCE: EcoSanteDatabase? = null

    fun get(context: Context): EcoSanteDatabase {
        return INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                EcoSanteDatabase::class.java,
                "ecosante.db"
            )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
