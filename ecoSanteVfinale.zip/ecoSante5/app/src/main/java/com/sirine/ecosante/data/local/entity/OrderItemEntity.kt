package com.sirine.ecosante.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "order_items")
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long = 0,
    val userId: Long,
    val productId: Long,
    val name: String,
    val quantity: Int,
    val unitPrice: Double
)
