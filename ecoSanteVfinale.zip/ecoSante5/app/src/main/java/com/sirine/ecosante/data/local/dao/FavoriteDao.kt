package com.sirine.ecosante.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sirine.ecosante.data.local.entity.FavoriteEntity

@Dao
interface FavoriteDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun add(fav: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE userId = :userId AND productId = :productId")
    suspend fun remove(userId: Long, productId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE userId = :userId AND productId = :productId)")
    suspend fun isFavorite(userId: Long, productId: Long): Boolean

    @Query("SELECT productId FROM favorites WHERE userId = :userId ORDER BY createdAt DESC")
    suspend fun getFavoriteProductIds(userId: Long): List<Long>
}
