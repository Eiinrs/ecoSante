package com.sirine.ecosante.ui.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class FeedbackFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_feedback, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val ratingBar = view.findViewById<RatingBar>(R.id.ratingFeedback)
        val editComment = view.findViewById<EditText>(R.id.editFeedbackComment)
        val buttonSend = view.findViewById<Button>(R.id.buttonSendFeedback)

        val app = requireActivity().application as EcoSanteApp
        val session = app.container.sessionManager
        val reviewRepo = app.container.reviewRepository

        buttonSend.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                val userId = session.currentUserId.firstOrNull()
                if (userId == null) {
                    Toast.makeText(requireContext(), "Connecte-toi pour laisser un avis", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val rating = ratingBar.rating.toInt()
                if (rating <= 0) {
                    Toast.makeText(requireContext(), "Choisis une note ", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val comment = editComment.text.toString().trim()

                reviewRepo.addReview(
                    userId = userId,
                    rating = rating,
                    comment = comment
                )

                Toast.makeText(requireContext(), "Merci pour ton avis !", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
        }
    }
}
