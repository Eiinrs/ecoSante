package com.sirine.ecosante.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirine.ecosante.data.repository.AuthRepository
import com.sirine.ecosante.data.session.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val error: String? = null
)

class AuthViewModel(
    private val repository: AuthRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _ui = MutableStateFlow(AuthUiState())
    val ui = _ui.asStateFlow()

    fun clearError() {
        _ui.value = _ui.value.copy(error = null)
    }

    fun login(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                _ui.value = _ui.value.copy(isLoading = true, error = null)

                val userId: Long = repository.login(email, password)
                sessionManager.login(userId)

                _ui.value = _ui.value.copy(isLoading = false)
                onSuccess()
            } catch (e: Exception) {
                _ui.value = _ui.value.copy(isLoading = false, error = e.message ?: "Erreur login")
            }
        }
    }


    fun register(
        email: String,
        password: String,
        fullName: String,
        profession: String,
        age: Int,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                _ui.value = _ui.value.copy(isLoading = true, error = null)

                val userId: Long = repository.register(email, password, fullName, profession, age)

                sessionManager.login(userId)
                _ui.value = _ui.value.copy(isLoading = false)
                onSuccess()
            } catch (e: Exception) {
                _ui.value = _ui.value.copy(isLoading = false, error = e.message ?: "Erreur register")
            }
        }
    }
}
