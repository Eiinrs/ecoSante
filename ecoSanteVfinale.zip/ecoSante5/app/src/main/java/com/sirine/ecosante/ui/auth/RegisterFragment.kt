package com.sirine.ecosante.ui.auth

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.sirine.ecosante.EcoSanteApp
import com.sirine.ecosante.R
import kotlinx.coroutines.launch

class RegisterFragment : Fragment() {

    private lateinit var viewModel: AuthViewModel

    private lateinit var editFirstName: EditText
    private lateinit var editLastName: EditText
    private lateinit var editAge: EditText
    private lateinit var spinnerProfession: Spinner
    private lateinit var editProfessionOther: EditText
    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var editPasswordConfirm: EditText
    private lateinit var buttonRegister: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_register, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as EcoSanteApp
        viewModel = ViewModelProvider(
            this,
            AuthViewModelFactory(app.container.authRepository, app.container.sessionManager)
        )[AuthViewModel::class.java]

        editFirstName = view.findViewById(R.id.editFirstName)
        editLastName = view.findViewById(R.id.editLastName)
        editAge = view.findViewById(R.id.editAge)
        spinnerProfession = view.findViewById(R.id.spinnerProfession)
        editProfessionOther = view.findViewById(R.id.editProfessionOther) //  AJOUT dans XML
        editEmail = view.findViewById(R.id.editEmail)
        editPassword = view.findViewById(R.id.editPassword)
        editPasswordConfirm = view.findViewById(R.id.editPasswordConfirm)
        buttonRegister = view.findViewById(R.id.buttonRegister)

        val professions = listOf(
            "Médecin",
            "Infirmier(ère)",
            "Sage-femme",
            "Technicien(ne) biomédical",
            "Pharmacien(ne)",
            "Autre"
        )

        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, professions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerProfession.adapter = adapter

        // Affiche champ "Autre" si besoin
        editProfessionOther.isVisible = false
        spinnerProfession.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, v: View?, position: Int, id: Long) {
                val selected = professions[position]
                editProfessionOther.isVisible = (selected == "Autre")
                if (selected != "Autre") editProfessionOther.setText("")
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.ui.collect { state ->
                state.error?.let { msg ->
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearError()
                }
            }
        }

        buttonRegister.setOnClickListener { registerUser() }
    }

    private fun registerUser() {
        val firstName = editFirstName.text.toString().trim()
        val lastName = editLastName.text.toString().trim()
        val ageText = editAge.text.toString().trim()
        val email = editEmail.text.toString().trim()
        val password = editPassword.text.toString()
        val passwordConfirm = editPasswordConfirm.text.toString()

        val selectedProfession = spinnerProfession.selectedItem?.toString() ?: ""
        val profession = if (selectedProfession == "Autre") {
            editProfessionOther.text.toString().trim()
        } else selectedProfession

        if (firstName.isEmpty() || lastName.isEmpty() || ageText.isEmpty()
            || email.isEmpty() || password.isEmpty() || passwordConfirm.isEmpty()
            || profession.isEmpty()
        ) {
            Toast.makeText(requireContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            return
        }

        val ageInt = ageText.toIntOrNull()
        if (ageInt == null || ageInt <= 0) {
            Toast.makeText(requireContext(), "Âge invalide", Toast.LENGTH_SHORT).show()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(requireContext(), "Format email invalide", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 8) {
            Toast.makeText(requireContext(), "Mot de passe trop court (min 8)", Toast.LENGTH_SHORT).show()
            return
        }

        if (password != passwordConfirm) {
            Toast.makeText(requireContext(), "Les mots de passe ne correspondent pas", Toast.LENGTH_SHORT).show()
            return
        }

        val fullName = "$firstName $lastName"

        // on passe bien profession + age
        viewModel.register(
            email = email,
            password = password,
            fullName = fullName,
            profession = profession,
            age = ageInt
        ) {
            Toast.makeText(requireContext(), "Compte créé ! ", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }
}
