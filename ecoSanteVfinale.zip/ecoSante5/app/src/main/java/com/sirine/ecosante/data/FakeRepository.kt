package com.sirine.ecosante.data

import com.sirine.ecosante.R

object FakeRepository {

    private val products = listOf(
        Product(
            id = 1,
            name = "Échographe portable Mindray",
            category = "Imagerie",
            condition = "Reconditionné",
            price = 3500.0,
            imageResId = R.drawable.image1
        ),
        Product(
            id = 2,
            name = "Moniteur patient multiparamètres",
            category = "Monitoring",
            condition = "Occasion révisée",
            price = 980.0,
            imageResId = R.drawable.image2
        ),
        Product(
            id = 3,
            name = "Table d'examen électrique",
            category = "Mobilier médical",
            condition = "Très bon état",
            price = 750.0,
            imageResId = R.drawable.image3
        ),
        Product(
            id = 4,
            name = "Pousse-seringue Fresenius",
            category = "Perfusion",
            condition = "Reconditionné",
            price = 420.0,
            imageResId = R.drawable.image4
        ),
        Product(
            id = 5,
            name = "Luminaires bloc opératoire",
            category = "Bloc opératoire",
            condition = "Occasion",
            price = 2600.0,
            imageResId = R.drawable.image5
        )
    )

    fun getProducts(): List<Product> = products

    fun getProductById(id: Int): Product? =
        products.find { it.id == id }
}
