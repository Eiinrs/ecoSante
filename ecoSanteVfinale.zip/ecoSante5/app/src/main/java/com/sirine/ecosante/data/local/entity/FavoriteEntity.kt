package com.sirine.ecosante.data.local.entity

import androidx.room.Entity

@Entity(
    tableName = "favorites",
    primaryKeys = ["userId", "productId"]
)
data class FavoriteEntity(
    val userId: Long,
    val productId: Long,
    val createdAt: Long = System.currentTimeMillis()
)
