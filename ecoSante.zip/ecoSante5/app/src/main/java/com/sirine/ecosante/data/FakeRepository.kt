package com.sirine.ecosante.data

import com.sirine.ecosante.R

object FakeRepository {

    private val products = listOf(
        Product(
            id = 1,
            name = "Échographe portable Mindray",
            category = "Imagerie",
            condition = "Reconditionné",
            price = 3500.0,
            imageResId = R.drawable.ic_launcher_foreground
        ),
        Product(
            id = 2,
            name = "Moniteur patient multiparamètres",
            category = "Monitoring",
            condition = "Occasion révisée",
            price = 980.0,
            imageResId = R.drawable.ic_launcher_foreground
        ),
        Product(
            id = 3,
            name = "Table d'examen électrique",
            category = "Mobilier médical",
            condition = "Très bon état",
            price = 750.0,
            imageResId = R.drawable.ic_launcher_foreground
        ),
        Product(
            id = 4,
            name = "Pousse-seringue Fresenius",
            category = "Perfusion",
            condition = "Reconditionné",
            price = 420.0,
            imageResId = R.drawable.ic_launcher_foreground
        ),
        Product(
            id = 5,
            name = "Luminaires bloc opératoire",
            category = "Bloc opératoire",
            condition = "Occasion",
            price = 2600.0,
            imageResId = R.drawable.ic_launcher_foreground
        )
    )

    fun getProducts(): List<Product> = products

    fun getProductById(id: Int): Product? =
        products.find { it.id == id }
}
