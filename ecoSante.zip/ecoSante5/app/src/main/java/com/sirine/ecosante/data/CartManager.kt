package com.sirine.ecosante.data

object CartManager {

    private val items = mutableListOf<CartItem>()

    fun addToCart(product: Product, quantity: Int = 1) {
        val existing = items.find { it.product.id == product.id }
        if (existing != null) {
            existing.quantity += quantity
        } else {
            items.add(CartItem(product = product, quantity = quantity))
        }
    }

    fun removeFromCart(product: Product) {
        items.removeAll { it.product.id == product.id }
    }

    fun updateQuantity(product: Product, newQuantity: Int) {
        val item = items.find { it.product.id == product.id } ?: return
        item.quantity = newQuantity
    }

    fun setItemSelected(product: Product, selected: Boolean) {
        val item = items.find { it.product.id == product.id } ?: return
        item.isSelected = selected
    }

    fun setAllSelected(selected: Boolean) {
        items.forEach { it.isSelected = selected }
    }

    fun getItems(): List<CartItem> = items

    fun getTotalPrice(onlySelected: Boolean = false): Double {
        val list = if (onlySelected) items.filter { it.isSelected } else items
        return list.sumOf { it.product.price * it.quantity }
    }

    fun clear() {
        items.clear()
    }
}
