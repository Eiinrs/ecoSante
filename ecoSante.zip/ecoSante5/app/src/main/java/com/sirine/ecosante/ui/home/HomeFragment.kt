package com.sirine.ecosante.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.R
import com.sirine.ecosante.data.FakeRepository
import com.sirine.ecosante.data.Product
import com.sirine.ecosante.ui.detail.ProductDetailFragment

class HomeFragment : Fragment() {

    private lateinit var recyclerProducts: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var editSearch: EditText
    private lateinit var buttonCamera: ImageButton

    private val allProducts: List<Product> = FakeRepository.getProducts()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerProducts = view.findViewById(R.id.recyclerProducts)
        editSearch = view.findViewById(R.id.editSearch)
        buttonCamera = view.findViewById(R.id.buttonCamera)

        adapter = ProductAdapter(allProducts) { product ->
            openDetails(product)
        }

        recyclerProducts.layoutManager = LinearLayoutManager(requireContext())
        recyclerProducts.adapter = adapter

        editSearch.addTextChangedListener { text ->
            val query = text?.toString()?.trim()?.lowercase() ?: ""
            val filtered = if (query.isEmpty()) {
                allProducts
            } else {
                allProducts.filter {
                    it.name.lowercase().contains(query) ||
                            it.category.lowercase().contains(query)
                }
            }
            adapter.updateData(filtered)
        }

        buttonCamera.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Scan produit via caméra (simulation pour l’instant)",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun openDetails(product: Product) {
        val fragment = ProductDetailFragment.newInstance(product.id)
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }
}
