package com.sirine.ecosante.ui.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sirine.ecosante.R
import com.sirine.ecosante.data.CartManager
import com.sirine.ecosante.data.FakeRepository
import com.sirine.ecosante.data.FavoritesManager

class ProductDetailFragment : Fragment() {

    private var productId: Int = -1
    private var quantity: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        productId = arguments?.getInt(ARG_PRODUCT_ID) ?: -1
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_product_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val imageProduct = view.findViewById<ImageView>(R.id.imageProduct)
        val textName = view.findViewById<TextView>(R.id.textName)
        val textCategory = view.findViewById<TextView>(R.id.textCategory)
        val textCondition = view.findViewById<TextView>(R.id.textCondition)
        val textPrice = view.findViewById<TextView>(R.id.textPrice)
        val textQuantity = view.findViewById<TextView>(R.id.textQuantity)
        val buttonMinus = view.findViewById<Button>(R.id.buttonMinus)
        val buttonPlus = view.findViewById<Button>(R.id.buttonPlus)
        val buttonFavorite = view.findViewById<ImageButton>(R.id.buttonFavorite)
        val buttonAddToCart = view.findViewById<Button>(R.id.buttonAddToCart)

        val product = FakeRepository.getProductById(productId)
        if (product == null) {
            Toast.makeText(requireContext(), "Produit introuvable", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
            return
        }

        imageProduct.setImageResource(product.imageResId)
        textName.text = product.name
        textCategory.text = product.category
        textCondition.text = product.condition
        textPrice.text = "${product.price} €"
        textQuantity.text = quantity.toString()

        fun refreshFavoriteIcon() {
            if (FavoritesManager.isFavorite(product)) {
                buttonFavorite.setImageResource(R.drawable.ic_favorite_filled)
            } else {
                buttonFavorite.setImageResource(R.drawable.ic_favorite_border)
            }
        }

        refreshFavoriteIcon()

        buttonFavorite.setOnClickListener {
            FavoritesManager.toggleFavorite(product)
            refreshFavoriteIcon()
        }

        buttonPlus.setOnClickListener {
            quantity++
            textQuantity.text = quantity.toString()
        }

        buttonMinus.setOnClickListener {
            if (quantity > 1) {
                quantity--
                textQuantity.text = quantity.toString()
            }
        }

        buttonAddToCart.setOnClickListener {
            CartManager.addToCart(product, quantity)  // ⚠ suppose addToCart(product, qty) existe
            Toast.makeText(
                requireContext(),
                "$quantity x ${product.name} ajouté(s) au panier",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    companion object {
        private const val ARG_PRODUCT_ID = "product_id"

        fun newInstance(productId: Int): ProductDetailFragment {
            val f = ProductDetailFragment()
            f.arguments = Bundle().apply {
                putInt(ARG_PRODUCT_ID, productId)
            }
            return f
        }
    }
}
