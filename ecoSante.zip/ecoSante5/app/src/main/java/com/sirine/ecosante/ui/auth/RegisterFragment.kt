package com.sirine.ecosante.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.sirine.ecosante.R
import com.sirine.ecosante.data.User
import com.sirine.ecosante.data.UserManager

class RegisterFragment : Fragment() {

    private lateinit var editFirstName: EditText
    private lateinit var editLastName: EditText
    private lateinit var editAge: EditText
    private lateinit var spinnerProfession: Spinner
    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var editPasswordConfirm: EditText
    private lateinit var buttonRegister: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_register, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        editFirstName = view.findViewById(R.id.editFirstName)
        editLastName = view.findViewById(R.id.editLastName)
        editAge = view.findViewById(R.id.editAge)
        spinnerProfession = view.findViewById(R.id.spinnerProfession)
        editEmail = view.findViewById(R.id.editEmail)
        editPassword = view.findViewById(R.id.editPassword)
        editPasswordConfirm = view.findViewById(R.id.editPasswordConfirm)
        buttonRegister = view.findViewById(R.id.buttonRegister)

        val professions = listOf(
            "Médecin",
            "Infirmier(ère)",
            "Sage-femme",
            "Technicien(ne) biomédical",
            "Pharmacien(ne)",
            "Autre"
        )

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            professions
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerProfession.adapter = adapter

        buttonRegister.setOnClickListener { registerUser() }
    }

    private fun registerUser() {
        val firstName = editFirstName.text.toString().trim()
        val lastName = editLastName.text.toString().trim()
        val ageText = editAge.text.toString().trim()
        val email = editEmail.text.toString().trim()
        val password = editPassword.text.toString()
        val passwordConfirm = editPasswordConfirm.text.toString()
        val profession = spinnerProfession.selectedItem?.toString() ?: ""

        if (firstName.isEmpty() || lastName.isEmpty() || ageText.isEmpty()
            || email.isEmpty() || password.isEmpty() || passwordConfirm.isEmpty()
        ) {
            Toast.makeText(requireContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            return
        }

        val ageInt = ageText.toIntOrNull()
        if (ageInt == null || ageInt <= 0) {
            Toast.makeText(requireContext(), "Âge invalide", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(requireContext(), "Mot de passe trop court (min 6)", Toast.LENGTH_SHORT).show()
            return
        }

        if (password != passwordConfirm) {
            Toast.makeText(requireContext(), "Les mots de passe ne correspondent pas", Toast.LENGTH_SHORT).show()
            return
        }

        val user = User(
            firstName = firstName,
            lastName = lastName,
            age = ageInt,
            profession = profession,
            email = email,
            password = password
        )

        UserManager.register(user)

        Toast.makeText(requireContext(), "Compte créé (simulation) ✅", Toast.LENGTH_SHORT).show()

        parentFragmentManager.popBackStack()
    }
}
