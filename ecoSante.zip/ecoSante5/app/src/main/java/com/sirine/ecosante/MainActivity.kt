package com.sirine.ecosante

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.sirine.ecosante.ui.cart.CartFragment
import com.sirine.ecosante.ui.contact.ContactFragment
import com.sirine.ecosante.ui.home.HomeFragment
import com.sirine.ecosante.ui.profile.ProfileFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        if (savedInstanceState == null) {
            openFragment(HomeFragment())
            bottomNav.selectedItemId = R.id.menu_home
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menu_home -> {
                    openFragment(HomeFragment()); true
                }
                R.id.menu_cart -> {
                    openFragment(CartFragment()); true
                }
                R.id.menu_contact -> {
                    openFragment(ContactFragment()); true
                }
                R.id.menu_profile -> {
                    openFragment(ProfileFragment()); true
                }
                else -> false
            }
        }
    }

    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }
}
