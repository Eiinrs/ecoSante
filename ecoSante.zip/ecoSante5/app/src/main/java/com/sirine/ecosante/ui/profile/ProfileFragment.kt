package com.sirine.ecosante.ui.profile

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sirine.ecosante.AuthActivity
import com.sirine.ecosante.R
import com.sirine.ecosante.data.FavoritesManager
import com.sirine.ecosante.data.OrderManager
import com.sirine.ecosante.data.UserManager

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val textName = view.findViewById<TextView>(R.id.textName)
        val textEmail = view.findViewById<TextView>(R.id.textEmail)
        val textProfession = view.findViewById<TextView>(R.id.textProfession)
        val textAge = view.findViewById<TextView>(R.id.textAge)
        val textHistory = view.findViewById<TextView>(R.id.textHistory)
        val textFavorites = view.findViewById<TextView>(R.id.textFavorites)
        val buttonLogout = view.findViewById<ImageButton>(R.id.buttonLogout)

        // 👤 Infos utilisateur
        val user = UserManager.currentUser
        if (user != null) {
            textName.text = "${user.firstName} ${user.lastName}"
            textEmail.text = user.email
            textProfession.text = user.profession
            textAge.text = "${user.age} ans"
        } else {
            textName.text = "Utilisateur invité"
            textEmail.text = "Non connecté"
            textProfession.text = "-"
            textAge.text = "-"
        }

        // 🔓 Déconnexion
        buttonLogout.setOnClickListener {
            UserManager.currentUser = null
            Toast.makeText(requireContext(), "Déconnecté(e)", Toast.LENGTH_SHORT).show()

            val intent = Intent(requireContext(), AuthActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
        }

        // 🧾 Historique commandes
        val orders = OrderManager.getOrders()
        if (orders.isEmpty()) {
            textHistory.text = "Aucune commande pour le moment."
            textHistory.setOnClickListener(null)
        } else {
            val historyText = orders.joinToString("\n\n") { order ->
                val itemsText = order.items.joinToString("\n") { item ->
                    "• ${item.product.name} x${item.quantity} — ${item.product.price * item.quantity} €"
                }
                val addressText = order.address?.let { "\nAdresse : $it" } ?: ""
                "Commande #${order.id} – ${order.date}\n$itemsText\nTotal : ${order.total} €$addressText"
            }
            textHistory.text = historyText

            // clic => détail d’une commande + pseudo export .txt
            textHistory.setOnClickListener {
                val labels = orders.map { o -> "Commande #${o.id} – ${o.date}" }.toTypedArray()

                AlertDialog.Builder(requireContext())
                    .setTitle("Détails commande")
                    .setItems(labels) { _, which ->
                        val order = orders[which]
                        val detail = buildString {
                            append("Commande #${order.id} – ${order.date}\n\n")
                            order.items.forEach { item ->
                                append("• ${item.product.name} x${item.quantity} – ${item.product.price * item.quantity} €\n")
                            }
                            append("\nTotal : ${order.total} €")
                            order.address?.let { addr ->
                                append("\nAdresse : $addr")
                            }
                        }

                        AlertDialog.Builder(requireContext())
                            .setTitle("Commande #${order.id}")
                            .setMessage(detail)
                            .setPositiveButton("Exporter en .txt (simulation)") { _, _ ->
                                Toast.makeText(
                                    requireContext(),
                                    "Export .txt simulé pour la commande #${order.id}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            .setNegativeButton("Fermer", null)
                            .show()
                    }
                    .show()
            }
        }

        //  Favoris
        val favorites = FavoritesManager.getFavorites()
        if (favorites.isEmpty()) {
            textFavorites.text = "Vous n'avez pas encore de favoris."
        } else {
            val favText = favorites.joinToString("\n") { product ->
                "• ${product.name} (${product.category}) — ${product.price} €"
            }
            textFavorites.text = favText
        }
    }
}
