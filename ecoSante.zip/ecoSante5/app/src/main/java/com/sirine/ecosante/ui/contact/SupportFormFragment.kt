package com.sirine.ecosante.ui.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sirine.ecosante.R

class SupportFormFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_support_form, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val editEmail = view.findViewById<EditText>(R.id.editSupportEmail)
        val editSubject = view.findViewById<EditText>(R.id.editSupportSubject)
        val editMessage = view.findViewById<EditText>(R.id.editSupportMessage)
        val buttonSend = view.findViewById<Button>(R.id.buttonSendSupport)

        buttonSend.setOnClickListener {
            if (editEmail.text.isNullOrBlank() ||
                editSubject.text.isNullOrBlank() ||
                editMessage.text.isNullOrBlank()
            ) {
                Toast.makeText(requireContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Message envoyé au SAV (simulation)", Toast.LENGTH_LONG).show()
                parentFragmentManager.popBackStack()
            }
        }
    }
}
