package com.sirine.ecosante.ui.contact

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sirine.ecosante.R

class FeedbackFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_feedback, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val ratingBar = view.findViewById<RatingBar>(R.id.ratingFeedback)
        val editComment = view.findViewById<EditText>(R.id.editFeedbackComment)
        val buttonSend = view.findViewById<Button>(R.id.buttonSendFeedback)

        buttonSend.setOnClickListener {
            val rating = ratingBar.rating
            val comment = editComment.text.toString().trim()

            if (rating == 0f) {
                Toast.makeText(requireContext(), "Merci de donner une note", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(
                requireContext(),
                "Merci pour votre avis ($rating) (simulation)",
                Toast.LENGTH_LONG
            ).show()

            parentFragmentManager.popBackStack()
        }
    }
}
