package com.sirine.ecosante.ui.payment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.sirine.ecosante.R
import com.sirine.ecosante.data.CartManager
import com.sirine.ecosante.data.OrderManager
import com.sirine.ecosante.ui.profile.ProfileFragment

class CardPaymentFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_card_payment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val textTotal = view.findViewById<TextView>(R.id.textTotalToPay)
        val editCardHolder = view.findViewById<EditText>(R.id.editCardHolder)
        val editCardNumber = view.findViewById<EditText>(R.id.editCardNumber)
        val editExpiry = view.findViewById<EditText>(R.id.editExpiry)
        val editCvv = view.findViewById<EditText>(R.id.editCvv)
        val editAddress = view.findViewById<EditText>(R.id.editAddress)
        val buttonPayNow = view.findViewById<Button>(R.id.buttonPayNow)

        val lastOrder = OrderManager.getOrders().lastOrNull()
        val total = lastOrder?.total ?: 0.0
        textTotal.text = "Montant : $total €"

        buttonPayNow.setOnClickListener {
            val holder = editCardHolder.text.toString().trim()
            val number = editCardNumber.text.toString().trim()
            val expiry = editExpiry.text.toString().trim()
            val cvv = editCvv.text.toString().trim()
            val address = editAddress.text.toString().trim()

            // Champs obligatoires
            if (holder.isEmpty() || number.isEmpty() || expiry.isEmpty()
                || cvv.isEmpty() || address.isEmpty()
            ) {
                Toast.makeText(requireContext(), "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Numéro carte : 16 chiffres
            if (number.length != 16 || number.any { !it.isDigit() }) {
                Toast.makeText(requireContext(), "Numéro de carte invalide (16 chiffres attendus)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // CVV : 3 chiffres
            if (cvv.length != 3 || cvv.any { !it.isDigit() }) {
                Toast.makeText(requireContext(), "CVV invalide (3 chiffres)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Expiry : MM/AA
            if (expiry.length != 5 || expiry[2] != '/') {
                Toast.makeText(requireContext(), "Date invalide (format MM/AA)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val monthStr = expiry.substring(0, 2)
            val yearStr = expiry.substring(3, 5)
            val month = monthStr.toIntOrNull()
            val year = yearStr.toIntOrNull()
            if (month == null || year == null || month !in 1..12) {
                Toast.makeText(requireContext(), "Date d'expiration invalide", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // On enrichit la dernière commande avec l'adresse
            OrderManager.updateLastOrderAddress(address)

            Toast.makeText(requireContext(), "Paiement simulé", Toast.LENGTH_LONG).show()

            CartManager.clear()

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, ProfileFragment())
                .commit()
        }
    }
}
