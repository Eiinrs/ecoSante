package com.sirine.ecosante.data

object FavoritesManager {

    private val favoriteIds = mutableSetOf<Int>()

    fun toggleFavorite(product: Product) {
        if (favoriteIds.contains(product.id)) {
            favoriteIds.remove(product.id)
        } else {
            favoriteIds.add(product.id)
        }
    }

    fun isFavorite(product: Product): Boolean =
        favoriteIds.contains(product.id)

    fun getFavorites(): List<Product> =
        FakeRepository.getProducts().filter { favoriteIds.contains(it.id) }
}
