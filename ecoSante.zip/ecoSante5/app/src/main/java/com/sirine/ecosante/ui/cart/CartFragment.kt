package com.sirine.ecosante.ui.cart

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.R
import com.sirine.ecosante.data.CartManager
import com.sirine.ecosante.data.OrderManager
import com.sirine.ecosante.ui.payment.CardPaymentFragment

class CartFragment : Fragment() {

    private lateinit var recyclerCart: RecyclerView
    private lateinit var textEmpty: TextView
    private lateinit var textTotal: TextView
    private lateinit var checkboxSelectAll: CheckBox
    private lateinit var buttonPay: Button
    private lateinit var adapter: CartAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_cart, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerCart = view.findViewById(R.id.recyclerCart)
        textEmpty = view.findViewById(R.id.textEmpty)
        textTotal = view.findViewById(R.id.textTotal)
        checkboxSelectAll = view.findViewById(R.id.checkboxSelectAll)
        buttonPay = view.findViewById(R.id.buttonPay)

        recyclerCart.layoutManager = LinearLayoutManager(requireContext())

        adapter = CartAdapter(CartManager.getItems().toMutableList()) {
            refreshUi()
        }
        recyclerCart.adapter = adapter

        checkboxSelectAll.setOnCheckedChangeListener { _, isChecked ->
            CartManager.setAllSelected(isChecked)
            adapter.updateItems(CartManager.getItems())
            refreshUi()
        }

        buttonPay.setOnClickListener {
            val selectedItems = CartManager.getItems().filter { it.isSelected }
            if (selectedItems.isEmpty()) {
                Toast.makeText(requireContext(), "Aucun article sélectionné", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val total = selectedItems.sumOf { it.product.price * it.quantity }
            OrderManager.addOrder(selectedItems, total)

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, CardPaymentFragment())
                .addToBackStack(null)
                .commit()
        }

        refreshUi()
    }

    private fun refreshUi() {
        val items = CartManager.getItems()

        if (items.isEmpty()) {
            textEmpty.visibility = View.VISIBLE
            recyclerCart.visibility = View.GONE
            checkboxSelectAll.isChecked = false
            textTotal.text = "Total : 0 €"
        } else {
            textEmpty.visibility = View.GONE
            recyclerCart.visibility = View.VISIBLE

            checkboxSelectAll.setOnCheckedChangeListener(null)
            checkboxSelectAll.isChecked = items.all { it.isSelected }
            checkboxSelectAll.setOnCheckedChangeListener { _, isChecked ->
                CartManager.setAllSelected(isChecked)
                adapter.updateItems(CartManager.getItems())
                refreshUi()
            }

            val total = CartManager.getTotalPrice(onlySelected = true)
            textTotal.text = "Total : $total €"
        }

        adapter.updateItems(items)
    }
}
