package com.sirine.ecosante.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sirine.ecosante.R
import com.sirine.ecosante.data.FavoritesManager
import com.sirine.ecosante.data.Product

class ProductAdapter(
    private var items: List<Product>,
    private val onDetailsClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageProduct: ImageView = itemView.findViewById(R.id.imageProduct)
        val textName: TextView = itemView.findViewById(R.id.textName)
        val textCategory: TextView = itemView.findViewById(R.id.textCategory)
        val textPrice: TextView = itemView.findViewById(R.id.textPrice)
        val buttonDetails: Button = itemView.findViewById(R.id.buttonAddToCart)
        val buttonFavorite: ImageButton = itemView.findViewById(R.id.buttonFavorite)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = items[position]

        // Image + textes
        holder.imageProduct.setImageResource(product.imageResId)
        holder.textName.text = product.name
        holder.textCategory.text = product.category
        holder.textPrice.text = "${product.price} €"

        // Bouton détails (ouvre la page détail)
        holder.buttonDetails.text = "+ DÉTAILS"
        holder.buttonDetails.setOnClickListener {
            onDetailsClick(product)
        }

        // Icône favoris au bon état
        updateFavoriteIcon(holder, product)

        // Clic sur le cœur => toggle favori
        holder.buttonFavorite.setOnClickListener {
            FavoritesManager.toggleFavorite(product)
            updateFavoriteIcon(holder, product)
        }
    }

    private fun updateFavoriteIcon(holder: ProductViewHolder, product: Product) {
        if (FavoritesManager.isFavorite(product)) {
            holder.buttonFavorite.setImageResource(R.drawable.ic_favorite_filled)
        } else {
            holder.buttonFavorite.setImageResource(R.drawable.ic_favorite_border)
        }
    }

    fun updateData(newItems: List<Product>) {
        items = newItems
        notifyDataSetChanged()
    }
}
